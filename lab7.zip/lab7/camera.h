#ifndef CAMERA_H_INCLUDED
#define CAMERA_H_INCLUDED

void MoveCamera();

#endif // CAMERA_H_INCLUDED
