#ifndef LIGHT_H_INCLUDED
#define LIGHT_H_INCLUDED

void Init_Material();
void Init_Light();

#endif // LIGHT_H_INCLUDED
